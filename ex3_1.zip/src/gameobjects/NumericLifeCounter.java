package gameobjects;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.Renderable;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import java.awt.Color;

public class NumericLifeCounter extends GameObject {
    private static final int THREE_LIVES = 3;
    private static final int TWO_LIVES = 2;
    private static final int ONE_LIVES = 1;
    private Counter livesCounter;
    private GameObjectCollection gameObjects;
    private final TextRenderable renderable;
    private int numOfLives;
    /**
     * Construct a new NumericLifeCounter instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     */
    public NumericLifeCounter(Vector2 topLeftCorner,
                              Vector2 dimensions, Counter livesCounter, Renderable renderable,
                              GameObjectCollection gameObjectCollection, int numOfLives) {
        super(topLeftCorner,dimensions,null);
        TextRenderable textRenderable = new TextRenderable("3");
        this.renderer().setRenderable(textRenderable);
        this.renderable = textRenderable;
        this.livesCounter = livesCounter;
        this.gameObjects = gameObjectCollection;
        this.numOfLives = numOfLives;
//        gameObjectCollection.addGameObject(this);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
//        this.renderer().setRenderable();
        switch (this.livesCounter.value()) {
            case THREE_LIVES:
                this.renderable.setString("3");
                this.renderable.setColor(Color.green);
                break;
            case TWO_LIVES:
                this.renderable.setString("2");
                this.renderable.setColor(Color.yellow);
                break;
            case ONE_LIVES:
                this.renderable.setString("1");
                this.renderable.setColor(Color.red);
                break;
        }
    }
}
