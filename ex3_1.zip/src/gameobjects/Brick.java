package gameobjects;

import brick_strategies.CollisionStrategy;
import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;


public class Brick extends GameObject {
    private CollisionStrategy collisionStrategy;
    private Counter brickCounter;

    /**
     * Construct a new Brick instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     */
    public Brick(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,  CollisionStrategy strategy,
                 Counter brickCounter) {
        super(topLeftCorner, dimensions, renderable);
        this.collisionStrategy = strategy;
        this.brickCounter = brickCounter;
    }

    @Override
    public void onCollisionEnter(GameObject other, Collision  collision) {
        super.onCollisionEnter(other, collision);
        this.collisionStrategy.onCollision(this,other, brickCounter);
//        collision.getNormal();
//        Vector2 newVelocity = getVelocity().flipped(collision.getNormal());
//        setVelocity(newVelocity);
//        this.collisionStrategy.onCollision(this, other,brickCounter, collision);
//        collisionSound.play();
    }
}
