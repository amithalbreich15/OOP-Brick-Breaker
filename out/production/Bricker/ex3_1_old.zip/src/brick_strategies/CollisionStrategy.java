package src.brick_strategies;

import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.components.Component;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;

public class CollisionStrategy {
    private final GameObjectCollection gameObjectCollection;

    public CollisionStrategy(GameObjectCollection gameObjectCollection) {
        this.gameObjectCollection = gameObjectCollection;
    };

    public void onCollision(GameObject brick, GameObject ball, Counter bricksCounter) {
        gameObjectCollection.removeGameObject(brick);
        bricksCounter.decrement();
    }



}
