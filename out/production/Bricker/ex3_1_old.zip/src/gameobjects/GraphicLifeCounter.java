package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;

public class GraphicLifeCounter extends GameObject {
    private Counter livesCounter;
    private int numOfLives;
    private GameObjectCollection gameObjectCollection;

    /**
     * Construct a new GaGraphicLifeCounter Object instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     */
    public GraphicLifeCounter(Vector2 topLeftCorner, Vector2 dimensions, Counter livesCounter,
                              Renderable renderable, GameObjectCollection gameObjectCollection, int numOfLives) {
        super(topLeftCorner, dimensions, renderable);
        this.livesCounter = livesCounter;
        this.numOfLives = numOfLives;
        this.gameObjectCollection = gameObjectCollection;
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        if(this.livesCounter.value()!= numOfLives){
            numOfLives--;
//            this.gameObjectCollection.removeGameObject(this);
        }

    }
}
