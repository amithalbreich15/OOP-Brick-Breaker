package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.util.Counter;

import java.util.Random;

public class DoubleDownStrategy extends CollisionStrategy {
    private static final String COLLISION_STRATEGY = "CollisionStrategy";
    private static final String ADD_PADDLE_STRATEGY = "AddPaddleStrategy";
    private static final String CHANGE_CAMERA_STRATEGY = "ChangeCameraStrategy";
    private static final String PUCK_STRATEGY = "PuckStrategy";
    private static final String GET_EXTRA_LIFE_STRATEGY = "GetExtraLifeStrategy";
    private static final String DOUBLE_DOWN_STRATEGY = "DoubleDownStrategy";
    private static final int COLLISION_STRATEGY_IDX = 0;
    private static final int ADD_PADDLE_STRATEGY_IDX = 1;
    private static final int CHANGE_CAMERA_STRATEGY_IDX = 2;
    private static final int PUCK_STRATEGY_IDX = 3;
    private static final int GET_EXTRA_LIFE_STRATEGY_IDX = 4;
    private static final int DOUBLE_DOWN_STRATEGY_IDX = 5;
    private static final int MAX_POWERUPS = 3;
    private final Counter powerUpsCounter;
    private int[] strategyIdxArr = new int[]{COLLISION_STRATEGY_IDX, ADD_PADDLE_STRATEGY_IDX,
            CHANGE_CAMERA_STRATEGY_IDX, PUCK_STRATEGY_IDX, GET_EXTRA_LIFE_STRATEGY_IDX, DOUBLE_DOWN_STRATEGY_IDX};
    private GameObjectCollection gameObjectCollection;
    private CollisionStrategy[] brickStrategies;
    private BrickStrategyFactory brickStrategyFactory;
    private int[] specificStrategiesIdx = new int[]{-1, -1, -1};
    private int doubleAmount = 0;

    public DoubleDownStrategy(BrickStrategyFactory brickStrategyFactory, GameObjectCollection gameObjectCollection, int doubleAmount) {
        super(gameObjectCollection);
        this.gameObjectCollection = gameObjectCollection;
        this.brickStrategies = new CollisionStrategy[MAX_POWERUPS];
        this.powerUpsCounter = new Counter(0);
        this.brickStrategyFactory = brickStrategyFactory;
        this.brickStrategies = new CollisionStrategy[MAX_POWERUPS];
        this.specificStrategiesIdx = new int[]{-1, -1, -1};
        this.doubleAmount = doubleAmount;
//        this.collisionStrategy = collisionStrategy;
        this.specificStrategiesIdx = getRandomStrategy();
        for (int i = 0; i < MAX_POWERUPS; i++) {
            if (specificStrategiesIdx[i] != -1) {
                brickStrategies[i] = this.brickStrategyFactory.buildStrategy(specificStrategiesIdx[i]);
            }

        }
    }

    @Override
    public void onCollision(GameObject collidedObj, GameObject colliderObj, Counter bricksCounter) {
        super.onCollision(collidedObj, colliderObj, bricksCounter);
        for (int i = 0; i < MAX_POWERUPS; i++) {
            if (brickStrategies[i] != null) {
                this.brickStrategies[i].onCollision(collidedObj, colliderObj, bricksCounter);
            }
        }
    }

    private boolean checkMaxStrategies(int[] strategiesArray, int doubleAmount) {
        return (doubleAmount == 1 && !(strategiesArray[0] == -1) && strategiesArray[1] == -1) ||
                (doubleAmount == 2 && !(strategiesArray[0] == -1) && (strategiesArray[1] == -1) &&
                        strategiesArray[2] == -1) || (doubleAmount == 2 && !(strategiesArray[0] == -1) &&
                !(strategiesArray[1] == -1) && strategiesArray[2] == -1);
    }

    private int[] getRandomStrategy() {
        Random random = new Random();
        int randomStrategy = random.nextInt(6);
        int strategiesSize = 0;
        while ((checkMaxStrategies(specificStrategiesIdx, doubleAmount) || specificStrategiesIdx[0] == -1)) {
            if (doubleAmount == 1)
            {
                randomStrategy = random.nextInt(1, 6);
            }
            if (doubleAmount == 2){
                randomStrategy = random.nextInt(1,5);
            }
            int brickStrategy = -1;
            switch (randomStrategy) {
                case COLLISION_STRATEGY_IDX:
                    brickStrategy = COLLISION_STRATEGY_IDX;
                    specificStrategiesIdx[strategiesSize++] = brickStrategy;
                    break;
                case ADD_PADDLE_STRATEGY_IDX:
                    brickStrategy = ADD_PADDLE_STRATEGY_IDX;
                    specificStrategiesIdx[strategiesSize++] = brickStrategy;
                    break;
                case CHANGE_CAMERA_STRATEGY_IDX:
                    brickStrategy = CHANGE_CAMERA_STRATEGY_IDX;
                    specificStrategiesIdx[strategiesSize++] = brickStrategy;
                    break;
                case PUCK_STRATEGY_IDX:
                    brickStrategy = PUCK_STRATEGY_IDX;
                    specificStrategiesIdx[strategiesSize++] = brickStrategy;
                    break;
                case GET_EXTRA_LIFE_STRATEGY_IDX:
                    brickStrategy = GET_EXTRA_LIFE_STRATEGY_IDX;
                    specificStrategiesIdx[strategiesSize++] = brickStrategy;
                    break;
                case DOUBLE_DOWN_STRATEGY_IDX:
                    doubleAmount++;
                    break;
            }
        }
        return specificStrategiesIdx;
    }

}
