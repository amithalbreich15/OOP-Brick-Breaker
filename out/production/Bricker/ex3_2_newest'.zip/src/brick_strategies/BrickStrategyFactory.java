package src.brick_strategies;

import danogl.GameManager;
import danogl.collisions.GameObjectCollection;
import danogl.gui.*;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.Brick;
import src.gameobjects.GraphicLifeCounter;
import src.gameobjects.MockPaddle;
import src.gameobjects.NumericLifeCounter;

import java.util.Random;

public class BrickStrategyFactory {

    private static final int MAX_POWERUPS = 3;
    private final GameObjectCollection gameObjectCollection;
    private final ImageReader imageReader;
    private static final int COLLISION_STRATEGY_IDX = 0;
    private static final int ADD_PADDLE_STRATEGY_IDX = 1;
    private static final int CHANGE_CAMERA_STRATEGY_IDX = 2;
    private static final int PUCK_STRATEGY_IDX = 3;
    private static final int GET_EXTRA_LIFE_STRATEGY_IDX = 4;
    private static final int DOUBLE_DOWN_STRATEGY_IDX = 5;
    private final MockPaddle mockPaddle;
    private final UserInputListener inputListener;
    private final Vector2 windowDimensions;
    private final Sound collisionSound;
    private final SoundReader soundReader;
    private final CollisionStrategy[] brickStrategies;
    private GameManager gameManager;
    private WindowController windowController;
    private GraphicLifeCounter graphicLifeCounter;
    private NumericLifeCounter numericLifeCounter;
    private Counter livesCounter;
    private CollisionStrategy[] collisionStrategies;
    private int doubleAmount = 0;

    public BrickStrategyFactory( GameObjectCollection gameObjectCollection, MockPaddle mockPaddle,
                                ImageReader imageReader, UserInputListener inputListener,
                                Vector2 windowDimensions, Sound collisionSound, SoundReader soundReader,
                                GameManager gameManager, WindowController windowController,
                                GraphicLifeCounter graphicLifeCounter, NumericLifeCounter numericLifeCounter,
                                Counter livesCounter)
    {
        this.gameObjectCollection = gameObjectCollection;
        this.mockPaddle = mockPaddle;
        this.imageReader = imageReader;
        this.inputListener = inputListener;
        this.windowDimensions = windowDimensions;
        this.collisionSound = collisionSound;
        this.soundReader = soundReader;
        this.gameManager = gameManager;
        this.windowController = windowController;
        this.graphicLifeCounter = graphicLifeCounter;
        this.numericLifeCounter = numericLifeCounter;
        this.livesCounter = livesCounter;
        this.brickStrategies = new CollisionStrategy[MAX_POWERUPS];
        this.collisionStrategies = new CollisionStrategy[]{new CollisionStrategy(gameObjectCollection),
                new AddPaddleStrategy(gameObjectCollection, imageReader, inputListener,windowDimensions),
                new ChangeCameraStrategy(gameObjectCollection, gameManager, windowController),
                new PuckStrategy(gameObjectCollection, imageReader, collisionSound,soundReader),
                new GetExtraLifeStrategy(gameObjectCollection, imageReader,
                        graphicLifeCounter, numericLifeCounter, livesCounter, windowDimensions)};
    }


    /**
     * buildPlayer function - builds a player according to the given playerType string - also not key sensitive.
     *
     * @param strategyType represents a given player type that need to be constructed.
     * @return return a player if playerType is in [whatever, clever, genius, human], null otherwise
     */
    public CollisionStrategy buildStrategy(int strategyType) {
        CollisionStrategy brickStrategy = null;
//        Random random = new Random();
//        if (doubleAmount == 1)
//        {
//            strategyType = random.nextInt(1, 6);
//        }
//        if (doubleAmount == 2){
//            strategyType = random.nextInt(1,5);
//        }
        switch (strategyType) {
            case COLLISION_STRATEGY_IDX:
                brickStrategy = new CollisionStrategy(gameObjectCollection);
                break;
            case ADD_PADDLE_STRATEGY_IDX:
                brickStrategy = new AddPaddleStrategy(gameObjectCollection, imageReader,
                        inputListener,windowDimensions);
                break;
            case CHANGE_CAMERA_STRATEGY_IDX:
                brickStrategy = new ChangeCameraStrategy(gameObjectCollection, gameManager, windowController);
                break;
            case PUCK_STRATEGY_IDX:
                brickStrategy = new PuckStrategy(gameObjectCollection, imageReader, collisionSound,soundReader);
                break;
            case GET_EXTRA_LIFE_STRATEGY_IDX:
                brickStrategy = new GetExtraLifeStrategy(gameObjectCollection, imageReader,
                        graphicLifeCounter, numericLifeCounter, livesCounter, windowDimensions);
                break;
            case DOUBLE_DOWN_STRATEGY_IDX:
                doubleAmount++;
                brickStrategy = new DoubleDownStrategy( this,gameObjectCollection, doubleAmount);
                doubleAmount = 0;
                break;
            default:
                break;
        }
        return brickStrategy;
    }
}
