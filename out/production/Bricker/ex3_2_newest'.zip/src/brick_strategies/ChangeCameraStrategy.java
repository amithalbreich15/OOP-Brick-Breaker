package src.brick_strategies;

import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.WindowController;
import danogl.gui.rendering.Camera;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.Puck;

public class ChangeCameraStrategy extends CollisionStrategy {
    private final GameObjectCollection gameObjectCollection;
    private GameManager gameManager;
    private WindowController windowController;

    public ChangeCameraStrategy(GameObjectCollection gameObjectCollection, GameManager gameManager,
                                WindowController windowController) {
        super(gameObjectCollection);
        this.gameObjectCollection = gameObjectCollection;
        this.gameManager = gameManager;
        this.windowController = windowController;
    }

    @Override
    public void onCollision(GameObject collidedObj, GameObject colliderObj, Counter bricksCounter) {
        super.onCollision(collidedObj,colliderObj,bricksCounter);
    if (gameManager.getCamera() == null && !(colliderObj instanceof Puck) ) {
            gameManager.setCamera( new Camera( colliderObj, Vector2.ZERO, windowController.getWindowDimensions().mult(1.2f),
                    windowController.getWindowDimensions()) );
        }

    }
}
