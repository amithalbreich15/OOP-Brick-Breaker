package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.Sound;
import danogl.gui.SoundReader;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.Puck;

import java.util.Random;

public class PuckStrategy extends CollisionStrategy {

    private static final int MOCK_BALLS_COUNT = 3;
    private static final float BALL_SPEED = 350;
    private final GameObjectCollection gameObjectCollection;
    private final ImageReader imageReader;
    private final SoundReader soundReader;

    public PuckStrategy(GameObjectCollection gameObjectCollection, ImageReader imageReader, Sound collisionSound, SoundReader soundReader) {
        super(gameObjectCollection);
        this.gameObjectCollection = gameObjectCollection;
        this.imageReader = imageReader;
        this.soundReader = soundReader;
    }

    @Override
    public void onCollision(GameObject collidedObj, GameObject colliderObj, Counter bricksCounter) {
        super.onCollision(collidedObj,colliderObj,bricksCounter);
        createMockBalls(imageReader,collidedObj,soundReader);


    }

    private void createMockBalls(ImageReader imageReader, GameObject collidedObj, SoundReader soundReader) {
        Sound collisionSound = soundReader.readSound("assets/blop.wav");
        Renderable mockBallImage = imageReader.readImage(
                "assets/mockBall.png", true);
        float brickWidthX= collidedObj.getDimensions().x();
        float brickHeightY= (float) collidedObj.getDimensions().y();
        for (int i = 1; i < MOCK_BALLS_COUNT; i++) {
            Puck mockBall = new Puck(new Vector2((collidedObj.getCenter().x()-brickWidthX/2)
                    + (i*brickWidthX)/3,collidedObj.getCenter().y()),
                    new Vector2(brickWidthX/3, brickWidthX/3),mockBallImage,collisionSound);
            float ballVelX = BALL_SPEED;
            float ballVelY = BALL_SPEED;
//            Random rand = new Random();
//            if (rand.nextBoolean())
//                ballVelX *= -1;
//            if (rand.nextBoolean())
//                ballVelY *= -1;
            mockBall.setVelocity(new Vector2(ballVelX, ballVelY));
            gameObjectCollection.addGameObject(mockBall);

        }
    }
}
