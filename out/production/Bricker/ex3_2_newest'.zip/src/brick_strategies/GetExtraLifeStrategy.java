package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.ExtraLife;
import src.gameobjects.GraphicLifeCounter;
import src.gameobjects.MockPaddle;
import src.gameobjects.NumericLifeCounter;

import java.util.Random;

public class GetExtraLifeStrategy extends CollisionStrategy {
    private static final int HEART_WIDTH = 25;
    private static final int HEART_HEIGHT = 25;
    private static final float EXTRA_LIFE_SPEED = 100;
    private final GameObjectCollection gameObjectCollection;
    private ImageReader imageReader;
    private ExtraLife extraLife;
    private GraphicLifeCounter graphicLifeCounter;
    private NumericLifeCounter numericLifeCounter;
    private Counter livesCounter;
    private Vector2 windowDimensions;
    private String[] strategiesStr;


    public GetExtraLifeStrategy(GameObjectCollection gameObjectCollection, ImageReader imageReader,
                                GraphicLifeCounter graphicLifeCounter, NumericLifeCounter numericLifeCounter,
                                Counter livesCounter, Vector2 windowDimensions) {
        super(gameObjectCollection);
        this.gameObjectCollection = gameObjectCollection;
        this.imageReader = imageReader;
        this.graphicLifeCounter = graphicLifeCounter;
        this.numericLifeCounter = numericLifeCounter;
        this.livesCounter = livesCounter;
        this.windowDimensions = windowDimensions;
    }

    public int incrementLivesCounter() { return livesCounter.value()+1 ; }

    public Counter setLivesCounter(Counter livesCounter) {
        this.livesCounter = livesCounter;
        return this.livesCounter;
    }

    @Override
    public void onCollision(GameObject collidedObj, GameObject colliderObj, Counter bricksCounter) {
        super.onCollision(collidedObj,colliderObj, bricksCounter);
         extraLife = createFallingLife(imageReader,collidedObj);
    }



    private ExtraLife createFallingLife(ImageReader imageReader, GameObject collidedObject) {
        Renderable livesImage =
                imageReader.readImage("assets/heart.png", true);
        ExtraLife heartSymbol = new ExtraLife(
                new Vector2(collidedObject.getCenter().x() - (float)(HEART_WIDTH/2),collidedObject.getCenter().y())
                ,new Vector2(HEART_WIDTH, HEART_HEIGHT),livesImage, gameObjectCollection, livesCounter,
                graphicLifeCounter, numericLifeCounter, windowDimensions);
        this.gameObjectCollection.addGameObject(heartSymbol);
        heartSymbol.setVelocity(new Vector2(0, EXTRA_LIFE_SPEED));
        return heartSymbol;
    }
}
