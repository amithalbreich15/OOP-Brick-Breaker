package src.gameobjects;

import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.util.Counter;

public class BallCollisionCountdownAgent {
    private static final int MAX_COLLISIONS = 4;
    private final Ball ball;
    private Counter collisionCounter;
    private GameObjectCollection gameObjectCollection;



    public BallCollisionCountdownAgent(Ball ball, Counter collisionCounter, GameObjectCollection gameObjectCollection) {
        this.ball = ball;
        this.collisionCounter = collisionCounter;
        this.gameObjectCollection = gameObjectCollection;
    }

    public void checkStopCameraEffect(GameObject ball, GameObject other, GameManager gameManager) {
        if (collisionCounter.value() == 0) {
            gameManager.setCamera(null);
            collisionCounter.increaseBy(MAX_COLLISIONS);
        }
        else {
            collisionCounter.decrement();
        }
    }
}
