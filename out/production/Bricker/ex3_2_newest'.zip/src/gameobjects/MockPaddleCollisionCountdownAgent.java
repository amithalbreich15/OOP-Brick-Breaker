package src.gameobjects;

import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.util.Counter;

public class MockPaddleCollisionCountdownAgent {
    private static final int MAX_COLLISIONS = 3;
    private final MockPaddle mockPaddle;
    private Counter collisionCounter;
    private GameObjectCollection gameObjectCollection;
    private Counter paddleCounter;



    public MockPaddleCollisionCountdownAgent(MockPaddle mockPaddle, Counter collisionCounter,
                                       GameObjectCollection gameObjectCollection, Counter paddleCounter) {
        this.mockPaddle = mockPaddle;
        this.collisionCounter = collisionCounter;
        this.gameObjectCollection = gameObjectCollection;
        this.paddleCounter = paddleCounter;
    }

    public void checkShouldPaddleDisappear(GameObject mockPaddle, GameObject other, Counter paddleCounter) {
        if (collisionCounter.value() == 0) {
            gameObjectCollection.removeGameObject(mockPaddle);
            paddleCounter.decrement();
            collisionCounter.increaseBy(MAX_COLLISIONS);
        }
        collisionCounter.decrement();
    }
}

