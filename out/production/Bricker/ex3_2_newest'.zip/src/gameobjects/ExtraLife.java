package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;

public class ExtraLife extends GameObject {
    private int MAX_LIVE_NUM = 4;
    private GameObjectCollection gameObjectCollection;
    private Counter livesCounter;
    private GraphicLifeCounter graphicLifeCounter;
    private NumericLifeCounter numericLifeCounter;
    private Vector2 windowDimensions;

    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     */
    public ExtraLife(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                     GameObjectCollection gameObjectCollection, Counter livesCounter,
                     GraphicLifeCounter graphicLifeCounter, NumericLifeCounter numericLifeCounter,
                     Vector2 windowDimensions) {
        super(topLeftCorner, dimensions, renderable);
        this.graphicLifeCounter = graphicLifeCounter;
        this.numericLifeCounter = numericLifeCounter;
        this.gameObjectCollection = gameObjectCollection;
        this.livesCounter = livesCounter;
        this.windowDimensions = windowDimensions;
    }

//    public void incrementLivesCounter() {  livesCounter.increment(); }

    private void onPaddleCollision(GameObject collidedObject, GameObject colliderObject) {
        gameObjectCollection.removeGameObject(collidedObject);
        if (graphicLifeCounter.getLivesCounter().value() < MAX_LIVE_NUM) {
            graphicLifeCounter.incrementLivesCounter();
            numericLifeCounter.incrementLivesCounter();
        }
    }

    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        onPaddleCollision(this,other);
    }

    @Override
    public boolean shouldCollideWith(GameObject other) {
        return (other instanceof Paddle) && !(other instanceof MockPaddle);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        if (this.getCenter().y() > this.windowDimensions.y()) {
            this.gameObjectCollection.removeGameObject(this);
        }
    }
}
